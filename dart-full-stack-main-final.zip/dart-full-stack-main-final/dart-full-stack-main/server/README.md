# Product Api

Run the server
```
dart_frog dev
```