package dev.flutter.provider_shopper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
